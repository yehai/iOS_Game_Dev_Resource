//
//  TouchingAppDelegate.h
//  Touching
//
//  Created by Canis Lupus
//  Copyright Wooji Juice 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TouchingAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

